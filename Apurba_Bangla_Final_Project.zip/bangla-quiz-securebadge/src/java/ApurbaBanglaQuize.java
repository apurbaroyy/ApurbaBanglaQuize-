/* Java code omitted in file for brevity; see README for details */
