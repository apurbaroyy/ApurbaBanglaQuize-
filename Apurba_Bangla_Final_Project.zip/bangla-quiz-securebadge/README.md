# Bangla Quiz with SecureBadge

Apurba Bangla Quiz App — Java Swing based Bengali quiz application with MySQL persistence and a simple SecureBadge engine for awarding badges based on score.

See docs/ directory for report skeleton and diagrams.
